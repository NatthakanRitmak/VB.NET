﻿Public Class Form1


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MessageBox.Show("รหัวนักศึกษา" + ID.Text + " ชื่อ " + Stname.Text + " นามสกุล " + Lastname.Text)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Environment.Exit(0)
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ID.TextChanged

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        ID.Text = "604272028"
        Stname.Text = "ณัฐกานต์"
        Lastname.Text = "ฤทธิ์มาก"
    End Sub
End Class
