﻿Public Class Form1

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Student_id.Text = "604272028"
        Student_Name.Text = "Natthakan Ritmak"
        Student_Email.Text = "Natthakan.rit@mail.pbru.ac.th"
        Dim birthdate As Date = #1/4/1998#
        Dim age As Integer
        age = Year(Today()) - Year(birthdate)
        Student_age.Text = age.ToString & " เกิดวัน " & birthdate.ToString("dddd")
        Student_enroll.Text = (16000 * 8).ToString("฿#,###")
    End Sub

    Private Sub Student_id_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Student_id.Click
        Student_id.Text = "604272028"
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Student_Name.Click

    End Sub

    Private Sub Label1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Student_Email.Click

    End Sub

    Private Sub Student_enrol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Student_enroll.Click

    End Sub
End Class
