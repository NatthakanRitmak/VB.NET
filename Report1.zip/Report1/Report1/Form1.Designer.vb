﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Student_id = New System.Windows.Forms.Label()
        Me.Student_Name = New System.Windows.Forms.Label()
        Me.Student_Email = New System.Windows.Forms.Label()
        Me.Student_age = New System.Windows.Forms.Label()
        Me.Student_enroll = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(68, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(150, 28)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "รายงานข้อมูลนักศึกษา"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Student_id
        '
        Me.Student_id.AutoSize = True
        Me.Student_id.Location = New System.Drawing.Point(33, 61)
        Me.Student_id.Name = "Student_id"
        Me.Student_id.Size = New System.Drawing.Size(69, 13)
        Me.Student_id.TabIndex = 1
        Me.Student_id.Text = "รหัสนักศึกษา"
        '
        'Student_Name
        '
        Me.Student_Name.AutoSize = True
        Me.Student_Name.Location = New System.Drawing.Point(33, 90)
        Me.Student_Name.Name = "Student_Name"
        Me.Student_Name.Size = New System.Drawing.Size(63, 13)
        Me.Student_Name.TabIndex = 2
        Me.Student_Name.Text = "ชื่อนักศึกษา"
        '
        'Student_Email
        '
        Me.Student_Email.AutoSize = True
        Me.Student_Email.Location = New System.Drawing.Point(33, 117)
        Me.Student_Email.Name = "Student_Email"
        Me.Student_Email.Size = New System.Drawing.Size(74, 13)
        Me.Student_Email.TabIndex = 3
        Me.Student_Email.Text = "อีเมล์นักศึกษา"
        '
        'Student_age
        '
        Me.Student_age.AutoSize = True
        Me.Student_age.Location = New System.Drawing.Point(34, 142)
        Me.Student_age.Name = "Student_age"
        Me.Student_age.Size = New System.Drawing.Size(68, 13)
        Me.Student_age.TabIndex = 4
        Me.Student_age.Text = "อายุนักศึกษา"
        '
        'Student_enroll
        '
        Me.Student_enroll.AutoSize = True
        Me.Student_enroll.Location = New System.Drawing.Point(33, 165)
        Me.Student_enroll.Name = "Student_enroll"
        Me.Student_enroll.Size = New System.Drawing.Size(134, 13)
        Me.Student_enroll.TabIndex = 5
        Me.Student_enroll.Text = "ค่าลงทะเบียนตลอดหลักสูตร"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.Student_enroll)
        Me.Controls.Add(Me.Student_age)
        Me.Controls.Add(Me.Student_Email)
        Me.Controls.Add(Me.Student_Name)
        Me.Controls.Add(Me.Student_id)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Student_id As System.Windows.Forms.Label
    Friend WithEvents Student_Name As System.Windows.Forms.Label
    Friend WithEvents Student_Email As System.Windows.Forms.Label
    Friend WithEvents Student_age As System.Windows.Forms.Label
    Friend WithEvents Student_enroll As System.Windows.Forms.Label

End Class
